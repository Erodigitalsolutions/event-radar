#!/usr/bin/env node
// Event Radar - utilidades deterministas (sin dependencias). Node >= 18.
//
//   node event-radar.mjs merge  --events events.json --incoming new.json
//   node event-radar.mjs score  --events events.json --goal customers [--weights '{"fit":30}'] [--liked "A,B"] [--today 2026-10-29]
//   node event-radar.mjs report --events events.json [--min-score 60] [--format md|csv] [--lang es|en] [--out file] [--today ...]
//   (tambien: dossier | contacts | reminders | ics | digest | crm | outcome | post-event | learn; ver references/events-schema.md)
//
// El modelo asigna sub-puntajes con evidencia; este script hace la matematica,
// el dedupe y el reporte para que sean reproducibles.

import fs from "node:fs";

const KEYS = ["fit", "audience", "people", "credibility", "cost", "logistics", "timing"];
// El presupuesto es solo un aliciente (peso bajo); nunca descarta un evento.
const BASE = { fit: 30, audience: 25, people: 15, credibility: 10, cost: 5, logistics: 10, timing: 5 };
const GOAL_ADJ = {
  customers: { audience: 10, people: 5, credibility: -5, timing: -5 },
  partners: { people: 10, audience: 5, logistics: -5, timing: -5 },
  suppliers: { people: 10, fit: 5, credibility: -5, audience: -5, timing: -5 },
  investors: { audience: 10, people: 10, logistics: -5, timing: -5 },
  learning: { fit: 10, credibility: 5, people: -5, audience: -5, timing: -5 },
  brand: { audience: 10, credibility: 5, people: -5, logistics: -5 },
  hiring: { audience: 10, fit: 5, credibility: -5, timing: -5 },
};
const LABELS = {
  es: { top: "Imperdible", high: "Muy recomendado", mid: "Vale la pena considerar" },
  en: { top: "Must-attend", high: "Highly recommended", mid: "Worth considering" },
};
const T = {
  es: {
    title: "Event Radar · Reporte", generated: "Generado", ranking: "Ranking", deadlines: "Próximos deadlines",
    none: "No hay eventos por encima del umbral.", when: "Fecha", where: "Lugar", tier: "Tier", cost: "Costo estimado",
    score: "Puntaje", breakdown: "Desglose", why: "Por qué", unverified: "No verificado", link: "Enlace",
    event: "Evento", label: "Etiqueta", reg: "Registro hasta", cfs: "Convocatoria de ponentes hasta",
    stretch: "Presupuesto", stretchTxt: "por encima del tope del tier (estiramiento posible, tú decides):", estimate: "estimado", priceUnknown: "precio no publicado", noDeadlines: "Sin deadlines próximos.",
    criteria: { fit: "Alineación", audience: "Audiencia", people: "Ponentes", credibility: "Credibilidad", cost: "Costo", logistics: "Logística", timing: "Timing" },
  },
  en: {
    title: "Event Radar · Report", generated: "Generated", ranking: "Ranking", deadlines: "Upcoming deadlines",
    none: "No events above the threshold.", when: "Date", where: "Location", tier: "Tier", cost: "Estimated cost",
    score: "Score", breakdown: "Breakdown", why: "Why", unverified: "Unverified", link: "Link",
    event: "Event", label: "Label", reg: "Register by", cfs: "Call for speakers until",
    stretch: "Budget", stretchTxt: "above the tier cap (stretch is your call):", estimate: "estimate", priceUnknown: "price not published", noDeadlines: "No upcoming deadlines.",
    criteria: { fit: "Fit", audience: "Audience", people: "Speakers", credibility: "Credibility", cost: "Cost", logistics: "Logistics", timing: "Timing" },
  },
};

// ---------- utilidades ----------
function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const k = a.slice(2);
      const v = argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[++i] : true;
      out[k] = v;
    } else out._.push(a);
  }
  return out;
}
const die = (m) => { console.error("Error: " + m); process.exit(1); };
const readJson = (p, fallback) => {
  if (!fs.existsSync(p)) { if (fallback !== undefined) return fallback; die(`no existe ${p}`); }
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch (e) { die(`JSON inválido en ${p}: ${e.message}`); }
};
const writeJson = (p, data) => fs.writeFileSync(p, JSON.stringify(data, null, 2) + "\n", "utf8");
const today = (a) => {
  const t = a.today || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) die("--today debe ser YYYY-MM-DD");
  return t;
};
const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
  .replace(/\b(19|20)\d{2}\b/g, " ").replace(/[^a-z0-9]+/g, " ").trim();
const urlKey = (u) => {
  if (!u) return null;
  try { const x = new URL(u); return (x.hostname.replace(/^www\./, "") + x.pathname).replace(/\/+$/, "").toLowerCase(); }
  catch { return null; }
};
const slug = (s) => norm(s).replace(/ /g, "-").slice(0, 60);
const eventsOf = (db) => (Array.isArray(db) ? db : db.events || []);
const isDate = (d) => typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d);

// ---------- merge ----------
const RESEARCH = new Set(["scores", "evidence", "unverified"]);
const PROTECTED = new Set(["status", "scores", "evidence", "first_seen", "score", "label", "filtered_reason", "notes", "unverified", "outcome"]);

function sameEvent(a, b) {
  const ua = urlKey(a.url), ub = urlKey(b.url);
  // Misma URL: solo es el mismo evento si el nombre coincide (una página puede listar varios eventos).
  if (ua && ub && ua === ub && (norm(a.name) === norm(b.name) || !a.name || !b.name)) return true;
  const ya = (a.start_date || "").slice(0, 4), yb = (b.start_date || "").slice(0, 4);
  return norm(a.name) !== "" && norm(a.name) === norm(b.name) && (!ya || !yb || ya === yb);
}

function cmdMerge(a) {
  if (!a.events || !a.incoming) die("uso: merge --events <events.json> --incoming <nuevos.json> [--refresh]");
  const db = readJson(a.events, { schema_version: 1, events: [] });
  const list = eventsOf(db);
  const incoming = eventsOf(readJson(a.incoming));
  const t = today(a);
  let added = 0, updated = 0, changed = [];
  for (const inc of incoming) {
    if (!inc.name) continue;
    const match = list.find((e) => sameEvent(e, inc));
    if (!match) {
      list.push({ id: slug(inc.name) + "-" + (inc.start_date || "tbd").slice(0, 4), status: "new", first_seen: t, last_checked: t, ...inc });
      added++;
    } else {
      for (const [k, v] of Object.entries(inc)) {
        if (v === null || v === undefined || v === "") continue;
        // Campos de investigacion: se completan si faltan; con --refresh (Fase 3) se reemplazan. Las decisiones del usuario nunca.
        const research = RESEARCH.has(k) && (a.refresh || match[k] == null || (Array.isArray(match[k]) && !match[k].length));
        if (PROTECTED.has(k) && !research) continue;
        if (JSON.stringify(match[k]) !== JSON.stringify(v)) {
          if (["start_date", "end_date", "city", "venue", "registration_deadline"].includes(k) && match[k]) changed.push(`${match.name}: ${k} ${match[k]} → ${v}`);
          match[k] = v;
        }
      }
      match.last_checked = t;
      updated++;
    }
  }
  const out = Array.isArray(db) ? { schema_version: 1, events: list } : { ...db, events: list };
  writeJson(a.events, out);
  const warnings = list.filter((e) => isDate(e.start_date) && isDate(e.end_date) && e.end_date < e.start_date)
    .map((e) => `${e.name}: end_date (${e.end_date}) es anterior a start_date (${e.start_date})`);
  console.log(JSON.stringify({ added, updated, total: list.length, changed_fields: changed, warnings }, null, 2));
}

// ---------- score ----------
function weightsFor(goal, custom) {
  const w = { ...BASE };
  if (goal && GOAL_ADJ[goal]) for (const [k, v] of Object.entries(GOAL_ADJ[goal])) w[k] += v;
  if (custom) for (const [k, v] of Object.entries(custom)) if (KEYS.includes(k) && Number.isFinite(v)) w[k] = v;
  for (const k of KEYS) w[k] = Math.max(0, w[k]);
  const sum = KEYS.reduce((s, k) => s + w[k], 0);
  if (sum === 0) die("los pesos suman 0");
  for (const k of KEYS) w[k] = w[k] / sum;
  return w;
}
function labelFor(score, lang) {
  const L = LABELS[lang] || LABELS.en;
  return score >= 85 ? L.top : score >= 70 ? L.high : score >= 60 ? L.mid : "";
}

function scoreEvent(e, w, liked, t) {
  const unverified = new Set(e.unverified || []);
  let total = 0;
  for (const k of KEYS) {
    let s = e.scores?.[k];
    if (typeof s !== "number" || s < 0 || s > 10) { s = 5; unverified.add(k); }
    total += w[k] * s;
  }
  let score = total * 10;
  const notes = [];
  if (e.registration_deadline && isDate(e.registration_deadline) && e.registration_deadline < t && (e.end_date || e.start_date || "9999") >= t) {
    score -= 5; notes.push("deadline de registro vencido (-5)");
  }
  const crit = [!e.start_date, !(e.city || e.venue), e.cost_estimate?.price_known === false || !e.prices?.length, !e.organizer].filter(Boolean).length;
  if (crit >= 3) { score -= 10; notes.push("campos críticos sin verificar (-10)"); }
  if (liked.some((l) => l && norm(e.name).includes(l))) { score += 5; notes.push("similar a uno que le gustó (+5)"); }
  return { score: Math.max(0, Math.min(100, Math.round(score * 10) / 10)), unverified: [...unverified], notes };
}

function cmdScore(a) {
  if (!a.events) die("uso: score --events <events.json> [--goal customers] [--weights JSON] [--liked 'A,B']");
  const db = readJson(a.events);
  const list = eventsOf(db);
  let custom = null;
  if (a.weights && a.weights !== true) { try { custom = JSON.parse(a.weights); } catch { die("--weights no es JSON válido"); } }
  if (a.goal && a.goal !== true && !GOAL_ADJ[a.goal]) console.error(`Aviso: goal "${a.goal}" sin ajuste; se usan pesos base.`);
  const w = weightsFor(a.goal === true ? null : a.goal, custom);
  const liked = a.liked && a.liked !== true ? a.liked.split(",").map(norm).filter(Boolean) : [];
  const lang = a.lang === "en" ? "en" : "es";
  const t = today(a);
  const out = { scored: 0, filtered_past: 0, skipped_no_scores: 0 };
  for (const e of list) {
    if (["cancelled", "skipped", "attended"].includes(e.status)) continue;
    const end = e.end_date || e.start_date;
    if (isDate(end) && end < t) { e.status = "filtered"; e.filtered_reason = "past"; out.filtered_past++; continue; }
    if (e.status === "filtered") continue;
    // Fase 3: solo se valoran los preseleccionados (o los ya valorados); --include-new puntua tambien la lista larga.
    if (e.status === "new" && !a["include-new"]) { out.left_in_longlist = (out.left_in_longlist || 0) + 1; continue; }
    if (!e.scores) { out.skipped_no_scores++; continue; }
    const r = scoreEvent(e, w, liked, t);
    e.score = r.score; e.label = labelFor(r.score, lang); e.unverified = r.unverified; e.score_notes = r.notes;
    if (["new", "shortlisted"].includes(e.status)) e.status = "candidate";
    out.scored++;
  }
  writeJson(a.events, Array.isArray(db) ? { schema_version: 1, events: list } : db);
  console.log(JSON.stringify({ ...out, weights: Object.fromEntries(KEYS.map((k) => [k, Math.round(w[k] * 1000) / 10])) }, null, 2));
}

// ---------- report ----------
const money = (c) => {
  if (!c) return null;
  const cur = c.currency || "";
  if (c.min == null && c.max == null) return null;
  return c.min === c.max || c.max == null ? `${cur} ${c.min}` : `${cur} ${c.min}–${c.max}`;
};
const csvCell = (v) => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };

function cmdReport(a) {
  if (!a.events) die("uso: report --events <events.json> [--min-score 60] [--format md|csv] [--lang es|en] [--out file]");
  const lang = a.lang === "en" ? "en" : "es";
  const tr = T[lang];
  const min = a["min-score"] ? Number(a["min-score"]) : 0;
  let caps = null;
  if (a.caps && a.caps !== true) { try { caps = JSON.parse(a.caps); } catch { die("--caps no es JSON válido, ej. '{\"1\":150,\"2\":600}'"); } }
  const t = today(a);
  const all = eventsOf(readJson(a.events));
  const rows = all.filter((e) => typeof e.score === "number" && e.score >= min && !["new", "filtered", "cancelled", "skipped"].includes(e.status))
    .sort((x, y) => y.score - x.score);

  let text;
  if ((a.format || "md") === "csv") {
    const head = ["name", "score", "label", "start_date", "end_date", "city", "country", "tier", "format", "cost_min", "cost_max", "currency", "registration_deadline", "status", "url"];
    text = [head.join(","), ...rows.map((e) => [e.name, e.score, e.label, e.start_date, e.end_date, e.city, e.country, e.tier, e.format,
      e.cost_estimate?.min, e.cost_estimate?.max, e.cost_estimate?.currency, e.registration_deadline, e.status, e.url].map(csvCell).join(","))].join("\n") + "\n";
  } else {
    const L = [`# ${tr.title}`, `_${tr.generated}: ${t} · ${rows.length} ${lang === "es" ? "eventos" : "events"}_`, ""];
    if (!rows.length) L.push(tr.none);
    else {
      L.push(`## ${tr.ranking}`, "", `| # | ${tr.event} | ${tr.score} | ${tr.label} | ${tr.when} | ${tr.where} |`, "|---|---|---|---|---|---|");
      rows.forEach((e, i) => L.push(`| ${i + 1} | ${e.name} | ${e.score} | ${e.label || ""} | ${e.start_date || "TBD"} | ${[e.city, e.country].filter(Boolean).join(", ") || "TBD"} |`));
      L.push("");
      rows.forEach((e, i) => {
        L.push(`### ${i + 1}. ${e.name} — ${e.score}${e.label ? " · " + e.label : ""}`, "");
        L.push(`- **${tr.when}:** ${e.start_date || "TBD"}${e.end_date && e.end_date !== e.start_date ? " → " + e.end_date : ""}`);
        L.push(`- **${tr.where}:** ${[e.venue, e.city, e.country].filter(Boolean).join(", ") || "TBD"} · ${tr.tier} ${e.tier ?? "?"}`);
        const m = money(e.cost_estimate);
        L.push(`- **${tr.cost}:** ${m ? m + " (" + tr.estimate + ")" : tr.priceUnknown}`);
        const cap = caps?.[e.tier];
        if (cap != null && e.cost_estimate?.min != null && e.cost_estimate.min > cap) L.push(`- **${tr.stretch}:** ${tr.stretchTxt} ${cap}`);
        if (e.registration_deadline) L.push(`- **${tr.reg}:** ${e.registration_deadline}`);
        if (e.call_for_speakers_deadline) L.push(`- **${tr.cfs}:** ${e.call_for_speakers_deadline}`);
        if (e.scores) L.push(`- **${tr.breakdown}:** ` + KEYS.map((k) => `${tr.criteria[k]} ${e.scores[k] ?? "?"}`).join(" · "));
        const why = Object.values(e.evidence || {}).map((v) => v.note).filter(Boolean);
        if (why.length) L.push(`- **${tr.why}:** ${why.join("; ")}`);
        if (e.unverified?.length) L.push(`- **${tr.unverified}:** ${e.unverified.map((k) => tr.criteria[k] || k).join(", ")}`);
        if (e.url) L.push(`- **${tr.link}:** ${e.url}`);
        L.push("");
      });
      const dl = [];
      for (const e of rows) {
        for (const [k, kind] of [["registration_deadline", tr.reg], ["call_for_speakers_deadline", tr.cfs]]) {
          if (isDate(e[k]) && e[k] >= t) dl.push({ d: e[k], text: `${e[k]} — ${e.name} (${kind})` });
        }
      }
      dl.sort((x, y) => x.d.localeCompare(y.d));
      L.push(`## ${tr.deadlines}`, "", ...(dl.length ? dl.map((x) => `- ${x.text}`) : [tr.noDeadlines]), "");
    }
    text = L.join("\n");
  }
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, text, "utf8"); console.log(`Reporte escrito en ${a.out} (${rows.length} eventos)`); }
  else process.stdout.write(text);
}

// ---------- longlist (fase 1 -> 2) y status ----------
const STATUSES = ["new", "shortlisted", "candidate", "watching", "deep-dive", "attending", "attended", "skipped", "filtered", "cancelled"];
const isOnline = (e) => e.online === true || e.format === "webinar" || /^online$/i.test(e.city || "");

function cmdLonglist(a) {
  if (!a.events) die("uso: longlist --events <events.json> [--status new,shortlisted] [--lang en|es] [--format md|csv] [--out file]");
  const lang = a.lang === "es" ? "es" : "en";
  const st = (a.status && a.status !== true ? a.status : "new").split(",");
  const t = today(a);
  const rank = { high: 0, medium: 1, low: 2 };
  const rows = eventsOf(readJson(a.events)).filter((e) => st.includes(e.status) && !(isDate(e.end_date || e.start_date) && (e.end_date || e.start_date) < t))
    .sort((x, y) => (x.tier ?? 9) - (y.tier ?? 9) || (rank[x.match] ?? 3) - (rank[y.match] ?? 3) || String(x.start_date || "9999").localeCompare(String(y.start_date || "9999")));
  const price = (e) => e.price_text || (e.prices?.length ? `${e.prices[0].currency} ${Math.min(...e.prices.map((p) => p.amount))}–${Math.max(...e.prices.map((p) => p.amount))}` : "n/a");
  const where = (e) => (isOnline(e) ? "Online" : [e.city, e.country].filter(Boolean).join(", ") || "TBD");
  let text;
  if ((a.format || "md") === "csv") {
    text = ["id,tier,name,match,match_reason,start_date,end_date,where,format,url", ...rows.map((e) => [e.id, e.tier, e.name, e.match, e.match_reason, e.start_date, e.end_date, where(e), e.format, e.url].map(csvCell).join(","))].join("\n") + "\n";
  } else {
    const H = lang === "es" ? { h: "Lista larga (todo lo que podría encajar)", n: "eventos", tier: "Tier", online: "Online / webinars", m: "Encaje", none: "Nada pendiente." } : { h: "Long list (everything that could match)", n: "events", tier: "Tier", online: "Online / webinars", m: "Match", none: "Nothing pending." };
    const L = [`# ${H.h}`, `_${t} · ${rows.length} ${H.n}_`, ""];
    if (!rows.length) L.push(H.none);
    let n = 0;
    const groups = [...new Set(rows.map((e) => (isOnline(e) ? "online" : e.tier ?? "?")))];
    for (const g of groups.sort((x, y) => (x === "online") - (y === "online") || String(x).localeCompare(String(y)))) {
      L.push(g === "online" ? `## ${H.online}` : `## ${H.tier} ${g}`, "", `| # | Event | Date | Where | Price | Description | ${H.m} |`, "|---|---|---|---|---|---|---|");
      for (const e of rows.filter((r) => (isOnline(r) ? "online" : r.tier ?? "?") === g))
        L.push(`| ${++n} | [${e.name}](${e.url || ""}) | ${e.start_date || "TBD"}${e.end_date && e.end_date !== e.start_date ? " → " + e.end_date : ""} | ${where(e)}${e.venue ? " (" + e.venue + ")" : ""} | ${price(e)} | ${e.description || e.match_reason || ""} | ${e.match || "?"} |`);
      L.push("");
    }
    text = L.join("\n");
  }
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, text, "utf8"); console.log(`Lista escrita en ${a.out} (${rows.length})`); } else process.stdout.write(text);
}

function cmdStatus(a) {
  if (!a.events || !a.ids || !a.set) die("uso: status --events <events.json> --ids id1,id2 --set shortlisted|watching|deep-dive|skipped|...");
  if (!STATUSES.includes(a.set)) die(`--set debe ser uno de: ${STATUSES.join(", ")}`);
  const db = readJson(a.events); const list = eventsOf(db);
  const ids = String(a.ids).split(",").map((s) => s.trim()).filter(Boolean);
  const changed = [], missing = [];
  for (const id of ids) { const e = list.find((x) => x.id === id); if (!e) { missing.push(id); continue; } changed.push(`${id}: ${e.status} -> ${a.set}`); e.status = a.set; }
  writeJson(a.events, Array.isArray(db) ? { schema_version: 1, events: list } : db);
  console.log(JSON.stringify({ changed, missing }, null, 2));
}

// ---------- dossier (esqueleto del briefing) ----------
function cmdDossier(a) {
  if (!a.events || !a.id) die("uso: dossier --events <events.json> --id <event-id> [--people people.json] [--out dossiers/<id>.md] [--lang en|es]");
  const lang = a.lang === "es" ? "es" : "en";
  const ev = eventsOf(readJson(a.events)).find((e) => e.id === a.id);
  if (!ev) die(`no existe el evento "${a.id}"`);
  const people = a.people && a.people !== true ? readJson(a.people, []) : [];
  const t = today(a);
  const H = lang === "es"
    ? { brief: "Briefing", prep: "Preparado", status: "Estado", score: "Puntaje", verdict: "Veredicto", glance: "El evento de un vistazo", cost: "Costo y logística", who: "Quién estará", cards: "Personas prioritarias (lista A)", plan: "Plan de acción", sources: "Fuentes", check: "Checklist previo", rec: "Recomendación", dates: "Fechas", place: "Lugar", reg: "Registro hasta", cfs: "Convocatoria de ponentes hasta", confirmed: "Confirmada", candidate: "Candidata", tbd: "Por completar" }
    : { brief: "Briefing", prep: "Prepared", status: "Status", score: "Score", verdict: "Verdict", glance: "Event at a glance", cost: "Cost & logistics", who: "Who will be there", cards: "Priority people (A list)", plan: "Game plan", sources: "Sources", check: "Pre-event checklist", rec: "Recommendation", dates: "Dates", place: "Place", reg: "Register by", cfs: "Call for speakers until", confirmed: "Confirmed", candidate: "Candidate", tbd: "TO COMPLETE" };
  const mine = people.filter((p) => !p.event_id || p.event_id === ev.id).sort((x, y) => (y.relevance ?? 0) - (x.relevance ?? 0));
  const L = [
    `# ${ev.name} · ${H.brief}`, `_${H.prep} ${t} · ${H.status}: ${ev.status || "?"} · ${H.score}: ${ev.score ?? "n/a"}${ev.label ? " (" + ev.label + ")" : ""}_`, "",
    `## 1. ${H.verdict}`, `**${H.rec}:** ${H.tbd}`, "",
    `## 2. ${H.glance}`, `- **${H.dates}:** ${ev.start_date || "TBD"}${ev.end_date && ev.end_date !== ev.start_date ? " → " + ev.end_date : ""}`,
    `- **${H.place}:** ${[ev.venue, ev.city, ev.country].filter(Boolean).join(", ") || "TBD"} (Tier ${ev.tier ?? "?"})`,
    `- **Format:** ${ev.format || "?"} · **Organizer:** ${ev.organizer || "?"}`, `- **URL:** ${ev.url || "?"}`, "",
    `## 3. ${H.cost}`,
  ];
  const m = money(ev.cost_estimate);
  L.push(`- Estimated total: ${m ? m + " (estimate)" : "price not published"}`);
  for (const p of ev.prices || []) L.push(`- ${p.label}: ${p.currency || ""} ${p.amount}${p.until ? " (until " + p.until + ")" : ""}`);
  if (ev.registration_deadline) L.push(`- ${H.reg}: ${ev.registration_deadline}`);
  if (ev.call_for_speakers_deadline) L.push(`- ${H.cfs}: ${ev.call_for_speakers_deadline}`);
  L.push("", `## 4. ${H.who}`, "", "| Pri | Name | Title | Company | Role | Rel. | Status |", "|---|---|---|---|---|---|---|");
  for (const p of mine) L.push(`| ${p.priority || "?"} | ${p.name} | ${p.title || ""} | ${p.company || ""} | ${p.role_in_event || ""} | ${p.relevance ?? "?"} | ${p.confirmed ? H.confirmed : H.candidate} |`);
  if (!mine.length) L.push(`| | ${H.tbd} | | | | | |`);
  L.push("", `## 5. ${H.cards}`, "");
  const top = mine.filter((p) => p.priority === "A");
  for (const p of top) {
    L.push(`### ${p.name} — ${p.title || ""}, ${p.company || ""} · ${p.confirmed ? H.confirmed : H.candidate}`,
      `- Why: ${p.why || H.tbd}`, `- Opener: ${p.opener ? '"' + p.opener + '"' : H.tbd}`, `- Question: ${p.question ? '"' + p.question + '"' : H.tbd}`,
      ...(p.linkedin_url ? [`- Public profile: ${p.linkedin_url}`] : []), `- Sources: ${(p.sources || []).join(" · ") || H.tbd}`, "");
  }
  if (!top.length) L.push(H.tbd, "");
  L.push(`## 6. ${H.plan}`, `- 30s pitch: ${H.tbd}`, `- Top targets / agenda: ${H.tbd}`, "",
    `## 7. ${H.sources}`, ...[ev.url, ...(ev.sources || [])].filter(Boolean).map((u) => `- ${u}`), "",
    `## 8. ${H.check}`, "- [ ] Registered (user does this; then set status `attending`)", "- [ ] Travel / lodging", "- [ ] Calendar + reminders", "- [ ] Meetings requested with A-list", "- [ ] CRM sheet updated", "");
  const text = L.join("\n");
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, text, "utf8"); console.log(`Dossier escrito en ${a.out}`); } else process.stdout.write(text);
}

// ---------- contacts (CSV para el CRM) ----------
function cmdContacts(a) {
  if (!a.people) die("uso: contacts --people <people.json> [--events events.json] [--min-priority B] [--out contactos.csv]");
  const people = readJson(a.people);
  const evs = a.events && a.events !== true ? eventsOf(readJson(a.events, { events: [] })) : [];
  const order = { A: 0, B: 1, C: 2 };
  const minP = order[a["min-priority"]] ?? 2;
  const rows = people.filter((p) => (order[p.priority] ?? 2) <= minP).sort((x, y) => (order[x.priority] ?? 2) - (order[y.priority] ?? 2) || (y.relevance ?? 0) - (x.relevance ?? 0));
  const head = ["event", "event_date", "priority", "name", "title", "company", "role_in_event", "confirmed", "relevance", "why", "public_profile", "source", "last_checked", "status", "followup_date", "notes"];
  const out = [head.join(","), ...rows.map((p) => {
    const ev = evs.find((e) => e.id === p.event_id) || {};
    return [ev.name || p.event_id, ev.start_date, p.priority, p.name, p.title, p.company, p.role_in_event, p.confirmed ? "yes" : "no", p.relevance, p.why,
      p.linkedin_url, (p.sources || [])[0], p.last_checked, "to-contact", "", ""].map(csvCell).join(",");
  })].join("\n") + "\n";
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, out, "utf8"); console.log(`Contactos escritos en ${a.out} (${rows.length})`); } else process.stdout.write(out);
}

// ---------- reminders / ics / digest ----------
const FOLLOWED = ["watching", "deep-dive", "attending"];
const pad = (n) => String(n).padStart(2, "0");
function addMonths(d, n) {
  const [y, m, day] = d.split("-").map(Number);
  const t = new Date(Date.UTC(y, m - 1 + n, 1));
  const last = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
  return `${t.getUTCFullYear()}-${pad(t.getUTCMonth() + 1)}-${pad(Math.min(day, last))}`;
}
function addDays(d, n) {
  const t = new Date(d + "T00:00:00Z"); t.setUTCDate(t.getUTCDate() + n);
  return t.toISOString().slice(0, 10);
}
const numList = (v, dflt) => (v && v !== true ? String(v).split(",").map(Number).filter(Number.isFinite) : dflt);

function buildReminders(a, events, t) {
  const months = numList(a["offsets-months"], [6, 3, 1]);
  const extraDays = numList(a["extra-days"], []);
  const regDays = numList(a["registered-days"], []);
  const dlDays = numList(a["deadline-days"], [14, 3]);
  const items = [];
  const push = (e, date, kind, offset, title, details) => {
    if (!isDate(date)) return;
    items.push({ key: `${e.id}|${kind}|${offset}|${date}`, date, event_id: e.id, event: e.name, kind, offset, title, details: details || "", url: e.url || "", missed: date < t });
  };
  for (const e of events) {
    if (!FOLLOWED.includes(e.status) || !isDate(e.start_date) || e.start_date < t) continue;
    const place = [e.city, e.country].filter(Boolean).join(", ");
    const info = `${e.start_date}${place ? " · " + place : ""}`;
    for (const n of months) push(e, addMonths(e.start_date, -n), "months-before", n, `${n} month${n > 1 ? "s" : ""} to ${e.name}`, info);
    for (const n of extraDays) push(e, addDays(e.start_date, -n), "days-before", n, `${n} days to ${e.name}`, info);
    if (e.status === "attending") for (const n of regDays) push(e, addDays(e.start_date, -n), "days-before", n, `${n} days to ${e.name} (registered)`, info);
    const dls = [];
    if (e.status !== "attending" && e.registration_deadline) dls.push(["registration-deadline", e.registration_deadline, "Registration closes"]);
    if (e.call_for_speakers_deadline) dls.push(["cfs-deadline", e.call_for_speakers_deadline, "Call for speakers closes"]);
    if (e.status !== "attending") for (const p of e.prices || []) if (p.until) dls.push(["price-deadline", p.until, `${p.label || "Price"} ends (${p.currency || ""} ${p.amount})`]);
    for (const [kind, date, label] of dls) {
      if (!isDate(date) || date < t) continue;
      for (const n of dlDays) push(e, addDays(date, -n), kind, n, `${label} in ${n} days: ${e.name}`, `${label}: ${date}`);
      push(e, date, kind, 0, `${label} TODAY: ${e.name}`, `${label}: ${date}`);
    }
  }
  return items.sort((x, y) => x.date.localeCompare(y.date) || x.event.localeCompare(y.event));
}

function loadState(p) { return p && p !== true ? readJson(p, { synced: [] }) : null; }

function cmdReminders(a) {
  if (!a.events) die("uso: reminders --events <events.json> [--offsets-months 6,3,1] [--extra-days 14] [--registered-days 14,7] [--deadline-days 14,3] [--window-days 60] [--state sync-state.json [--mark-synced]] [--all] [--out file.json]");
  const t = today(a);
  let items = buildReminders(a, eventsOf(readJson(a.events)), t);
  items = items.filter((i) => !i.missed);   // los vencidos no se crean; ver --include-missed
  if (a["include-missed"]) items = buildReminders(a, eventsOf(readJson(a.events)), t);
  if (a["window-days"] && a["window-days"] !== true) { const end = addDays(t, Number(a["window-days"])); items = items.filter((i) => i.date <= end); }
  const st = loadState(a.state);
  if (st && !a.all) items = items.filter((i) => !st.synced.includes(i.key));
  if (st && a["mark-synced"]) { st.synced = [...new Set([...st.synced, ...items.map((i) => i.key)])]; writeJson(a.state, st); }
  const text = JSON.stringify(items, null, 2) + "\n";
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, text, "utf8"); console.log(`${items.length} recordatorios escritos en ${a.out}`); } else process.stdout.write(text);
}

const icsEsc = (s) => String(s || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
const icsDate = (d) => d.replace(/-/g, "");
function cmdIcs(a) {
  if (!a.events || !a.out) die("uso: ics --events <events.json> --out <archivo.ics> [mismos flags que reminders]");
  const t = today(a);
  const events = eventsOf(readJson(a.events));
  const items = buildReminders(a, events, t).filter((i) => !i.missed);
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d+/, "");
  const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Event Radar//EN", "CALSCALE:GREGORIAN", "METHOD:PUBLISH"];
  const add = (uid, date, endDate, summary, desc, alarm) => {
    L.push("BEGIN:VEVENT", `UID:${uid}@event-radar`, `DTSTAMP:${stamp}`, `DTSTART;VALUE=DATE:${icsDate(date)}`, `DTEND;VALUE=DATE:${icsDate(addDays(endDate, 1))}`,
      `SUMMARY:${icsEsc(summary)}`, `DESCRIPTION:${icsEsc(desc)}`);
    if (alarm) L.push("BEGIN:VALARM", "ACTION:DISPLAY", `DESCRIPTION:${icsEsc(summary)}`, "TRIGGER;RELATED=START:PT9H", "END:VALARM");  // 09:00 del mismo dia (evento de dia completo empieza a las 00:00)
    L.push("END:VEVENT");
  };
  for (const e of events) if (FOLLOWED.includes(e.status) && isDate(e.start_date) && e.start_date >= t)
    add(`ev-${e.id}`, e.start_date, e.end_date || e.start_date, e.name, `${[e.venue, e.city, e.country].filter(Boolean).join(", ")}\n${e.url || ""}`, false);
  for (const i of items) add(i.key.replace(/[^a-zA-Z0-9-]/g, "_"), i.date, i.date, "⏰ " + i.title, `${i.details}\n${i.url}`, true);
  L.push("END:VCALENDAR");
  fs.writeFileSync(a.out, L.join("\r\n") + "\r\n", "utf8");
  console.log(`${a.out}: ${items.length} recordatorios + eventos seguidos`);
}

function cmdDigest(a) {
  if (!a.events) die("uso: digest --events <events.json> [--window-days 60] [--lang en|es] [--out file.md] [flags de reminders]");
  const lang = a.lang === "es" ? "es" : "en";
  const t = today(a);
  const win = Number(a["window-days"] && a["window-days"] !== true ? a["window-days"] : 60);
  const end = addDays(t, win);
  const events = eventsOf(readJson(a.events));
  const followed = events.filter((e) => FOLLOWED.includes(e.status) && isDate(e.start_date) && e.start_date >= t).sort((x, y) => x.start_date.localeCompare(y.start_date));
  const items = buildReminders(a, events, t).filter((i) => !i.missed && i.date <= end);
  const D = lang === "es"
    ? { h: "Qué viene", gen: "Generado", ev: "Eventos que sigues", none: "No sigues eventos todavía. Marca alguno como `watching`.", dl: `Próximos deadlines y avisos (${win} días)`, nodl: "Nada en esta ventana.", status: "Estado", reg: "registrado", watch: "en seguimiento", deep: "análisis a fondo" }
    : { h: "What's coming", gen: "Generated", ev: "Events you follow", none: "You are not following any events yet. Mark one as `watching`.", dl: `Upcoming deadlines & alerts (${win} days)`, nodl: "Nothing in this window.", status: "Status", reg: "registered", watch: "watching", deep: "deep-dive" };
  const stl = { attending: D.reg, watching: D.watch, "deep-dive": D.deep };
  const L = [`# ${D.h}`, `_${D.gen}: ${t}_`, "", `## ${D.ev}`, ""];
  if (!followed.length) L.push(D.none);
  else for (const e of followed) L.push(`- **${e.start_date}** — ${e.name} (${[e.city, e.country].filter(Boolean).join(", ") || "TBD"}) · ${D.status}: ${stl[e.status] || e.status}${e.url ? " · " + e.url : ""}`);
  L.push("", `## ${D.dl}`, "");
  if (!items.length) L.push(D.nodl); else for (const i of items) L.push(`- **${i.date}** — ${i.title}`);
  const text = L.join("\n") + "\n";
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, text, "utf8"); console.log(`Digest escrito en ${a.out}`); } else process.stdout.write(text);
}

// ---------- crm / outcome / post-event / learn (Fase 5) ----------
const CONTACT_STATUSES = ["to-contact", "contacted", "replied", "meeting", "opportunity", "won", "lost", "no-response", "not-relevant"];
const USER_COLS = ["status", "last_contact_date", "followup_date", "next_step", "notes"];
const CONTACT_HEAD = ["key", "event", "event_date", "priority", "name", "title", "company", "role_in_event", "confirmed", "relevance", "why", "public_profile", "source", "last_checked", ...USER_COLS];
const EVENT_HEAD = ["id", "name", "start_date", "end_date", "city", "country", "tier", "score", "label", "status", "url", "registration_deadline", "decision_reason", "rating", "leads", "meetings", "opportunities", "cost_actual", "currency", "would_return", "outcome_notes"];

function parseCsv(text) {
  const rows = []; let row = [], cell = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(cell); cell = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cell); cell = ""; if (row.some((x) => x !== "")) rows.push(row); row = []; }
    else cell += c;
  }
  if (cell !== "" || row.length) { row.push(cell); if (row.some((x) => x !== "")) rows.push(row); }
  return rows;
}
const toCsv = (rows) => rows.map((r) => r.map(csvCell).join(",")).join("\n") + "\n";
const contactKey = (p) => `${p.event_id || ""}|${norm(p.name)}`;
const FOLLOWUP_DAYS = { A: 2, B: 5, C: 10 };

function cmdCrm(a) {
  if (!a.events) die("uso: crm --events <events.json> [--people <people.json>] [--existing contacts-from-sheet.csv] [--out-dir dir] [--today ...]");
  const events = eventsOf(readJson(a.events));
  const people = a.people && a.people !== true ? readJson(a.people) : [];
  const dir = a["out-dir"] && a["out-dir"] !== true ? a["out-dir"] : ".";
  fs.mkdirSync(dir, { recursive: true });
  // Estado que el usuario edita en la hoja: se conserva por clave.
  const prev = new Map(); const prevRows = [];
  if (a.existing && a.existing !== true) {
    const t = parseCsv(fs.readFileSync(a.existing, "utf8")); const h = t[0] || [];
    if (!h.includes("key")) die("--existing debe tener columna 'key' (exporta la pestaña Contacts tal cual)");
    for (const r of t.slice(1)) { const o = {}; h.forEach((k, i) => (o[k] = r[i] ?? "")); prev.set(o.key, o); prevRows.push(o); }
  }
  const byId = new Map(events.map((e) => [e.id, e]));
  const seen = new Set(); const crows = [];
  for (const p of people) {
    const key = contactKey(p); seen.add(key);
    const ev = byId.get(p.event_id) || {};
    const old = prev.get(key) || {};
    let follow = old.followup_date || p.followup_date || "";
    if (!follow && isDate(ev.end_date) && ["attending", "attended"].includes(ev.status)) follow = addDays(ev.end_date, FOLLOWUP_DAYS[p.priority] ?? 10);
    const user = { status: old.status || p.status || "to-contact", last_contact_date: old.last_contact_date || "", followup_date: follow, next_step: old.next_step || "", notes: old.notes || p.notes || "" };
    if (!CONTACT_STATUSES.includes(user.status)) console.error(`Aviso: estado "${user.status}" de ${p.name} no es estándar (${CONTACT_STATUSES.join(", ")}).`);
    crows.push([key, ev.name || p.event_id, ev.start_date || "", p.priority || "", p.name, p.title, p.company, p.role_in_event, p.confirmed ? "yes" : "no", p.relevance, p.why, p.linkedin_url, (p.sources || [])[0], p.last_checked, ...USER_COLS.map((k) => user[k])]);
  }
  let kept = 0;
  for (const o of prevRows) if (!seen.has(o.key)) { crows.push(CONTACT_HEAD.map((k) => o[k] ?? "")); kept++; }
  const sheet = buildSheetTabs(events, today(a), a);
  const tabs = { ...sheet, Contacts: [CONTACT_HEAD, ...crows] };
  for (const [name, rows] of Object.entries(tabs)) fs.writeFileSync(`${dir}/crm-${name.toLowerCase()}.csv`, toCsv(rows), "utf8");
  writeJson(`${dir}/crm-sheet.json`, { tabs, statuses: CONTACT_STATUSES });
  writeXlsx(`${dir}/event-radar.xlsx`, tabs);
  const erows = tabs.Events.slice(1);
  console.log(JSON.stringify({ events: erows.length, prices: tabs.Prices.length - 1, timeline: tabs.Timeline.length - 1, scores: tabs.Scores.length - 1, contacts: crows.length, preserved_from_sheet: prev.size, kept_only_in_sheet: kept, out_dir: dir, workbook: `${dir}/event-radar.xlsx` }, null, 2));
}


// ---------- hoja de calculo: pestañas, xlsx sin dependencias, export ----------
const PRICE_TXT = (e) => e.price_text || money(e.cost_estimate) || "";
function nextPriceDeadline(e, t) {
  const ds = [...(e.prices || []).map((p) => p.until), e.registration_deadline].filter((d) => isDate(d) && d >= t).sort();
  return ds[0] || "";
}
function daysBetween(a, b) { return Math.round((Date.parse(b) - Date.parse(a)) / 86400000); }

function buildSheetTabs(events, t, a) {
  const NOT_TIMELINE = ["new", "filtered", "skipped", "cancelled", "attended"];
  const sorted = [...events].sort((x, y) => (y.score ?? -1) - (x.score ?? -1) || String(x.start_date || "9999").localeCompare(String(y.start_date || "9999")));
  const Events = [["id", "name", "status", "score", "label", "start_date", "end_date", "days_to_start", "city", "country", "venue", "tier", "format", "online", "organizer", "price_summary", "cost_est_min", "cost_est_max", "cost_currency", "price_known", "registration_deadline", "next_deadline", "url", "match", "why", "unverified", "last_checked", "decision_reason", "rating", "leads", "meetings", "opportunities", "cost_actual", "currency", "would_return", "outcome_notes"]];
  for (const e of sorted) {
    const o = e.outcome || {};
    const why = Object.values(e.evidence || {}).map((v) => v.note).filter(Boolean).join("; ") || e.match_reason || e.description || "";
    Events.push([e.id, e.name, e.status, e.score, e.label, e.start_date, e.end_date, isDate(e.start_date) ? daysBetween(t, e.start_date) : "", e.city, e.country, e.venue, e.tier, e.format, isOnline(e) ? "yes" : "no", e.organizer, PRICE_TXT(e),
      e.cost_estimate?.min, e.cost_estimate?.max, e.cost_estimate?.currency, e.cost_estimate ? (e.cost_estimate.price_known ? "yes" : "no") : "", e.registration_deadline, nextPriceDeadline(e, t), e.url, e.match, why, (e.unverified || []).join(", "), e.last_checked,
      e.filtered_reason || o.reason, o.rating, o.leads, o.meetings, o.opportunities, o.cost_actual, o.currency, o.would_return, o.notes]);
  }
  const Prices = [["event", "status", "label", "amount", "currency", "valid_until", "days_left", "note"]];
  for (const e of sorted) {
    for (const p of e.prices || []) Prices.push([e.name, e.status, p.label, p.amount, p.currency, p.until, isDate(p.until) ? daysBetween(t, p.until) : "", ""]);
    const c = e.cost_estimate;
    if (c && (c.min != null || c.max != null)) Prices.push([e.name, e.status, "Estimated total incl. travel (estimate)", c.min === c.max ? c.min : `${c.min}-${c.max}`, c.currency, "", "", c.price_known ? "ticket price published" : "ticket price NOT confirmed"]);
    else if (!(e.prices || []).length) Prices.push([e.name, e.status, "Price", "", "", "", "", e.price_text || "not published"]);
  }
  const Timeline = [["date", "days_from_today", "event", "status", "type", "description", "url"]];
  const tl = [];
  const add = (e, date, type, desc) => { if (isDate(date) && date >= t) tl.push([date, daysBetween(t, date), e.name, e.status, type, desc, e.url || ""]); };
  for (const e of events) {
    if (NOT_TIMELINE.includes(e.status)) continue;
    const place = isOnline(e) ? "Online" : [e.city, e.country].filter(Boolean).join(", ");
    add(e, e.start_date, "event", `${e.name}${e.end_date && e.end_date !== e.start_date ? " (until " + e.end_date + ")" : ""}${place ? " · " + place : ""}`);
    for (const p of e.prices || []) add(e, p.until, "price-deadline", `${p.label || "Price"} ends (${p.currency || ""} ${p.amount})`);
    add(e, e.registration_deadline, "registration-deadline", "Registration closes");
    add(e, e.call_for_speakers_deadline, "cfs-deadline", "Call for speakers closes");
  }
  for (const r of buildReminders(a, events, t)) if (!r.missed) tl.push([r.date, daysBetween(t, r.date), r.event, events.find((e) => e.id === r.event_id)?.status, "reminder", r.title, r.url]);
  tl.sort((x, y) => x[0].localeCompare(y[0]) || String(x[2]).localeCompare(String(y[2])));
  Timeline.push(...tl);
  const Scores = [["event", "status", "score", "label", ...KEYS, "evidence", "score_notes"]];
  for (const e of sorted) if (e.scores) Scores.push([e.name, e.status, e.score, e.label, ...KEYS.map((k) => e.scores[k]), Object.entries(e.evidence || {}).map(([k, v]) => `${k}: ${v.note}${v.url ? " (" + v.url + ")" : ""}`).join(" | "), (e.score_notes || []).join("; ")]);
  return { Events, Prices, Timeline, Scores };
}

// xlsx minimo (zip sin compresion, cadenas inline). Sin dependencias.
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (buf) => { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function zipStore(files) {
  const chunks = [], central = []; let offset = 0;
  for (const [name, content] of files) {
    const nb = Buffer.from(name, "utf8"), data = Buffer.from(content, "utf8"), crc = crc32(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(0, 8); lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26); lh.writeUInt16LE(0, 28);
    chunks.push(lh, nb, data);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(0, 10); ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nb.length, 28); ch.writeUInt32LE(offset, 42);
    central.push(ch, nb);
    offset += 30 + nb.length + data.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...chunks, cd, end]);
}
const xmlEsc = (s) => String(s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const colName = (i) => { let s = ""; for (let n = i + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s; return s; };
function sheetXml(rows) {
  const widths = rows[0].map((_, c) => Math.min(60, Math.max(10, ...rows.slice(0, 60).map((r) => String(r[c] ?? "").length + 2))));
  const cols = "<cols>" + widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join("") + "</cols>";
  const body = rows.map((r, ri) => `<row r="${ri + 1}">` + r.map((v, ci) => {
    if (v == null || v === "") return "";
    const ref = colName(ci) + (ri + 1), s = ri === 0 ? ' s="1"' : "";
    return typeof v === "number" && Number.isFinite(v) ? `<c r="${ref}"${s}><v>${v}</v></c>` : `<c r="${ref}"${s} t="inlineStr"><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`;
  }).join("") + "</row>").join("");
  const ref = `A1:${colName(rows[0].length - 1)}${rows.length}`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>${cols}<sheetData>${body}</sheetData><autoFilter ref="${ref}"/></worksheet>`;
}
function writeXlsx(file, tabs) {
  const names = Object.keys(tabs);
  const files = [
    ["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${names.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`],
    ["_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
    ["xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xmlEsc(n.slice(0, 31))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`],
    ["xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${names.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${names.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
    ["xl/styles.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>`],
    ...names.map((n, i) => [`xl/worksheets/sheet${i + 1}.xml`, sheetXml(tabs[n])]),
  ];
  fs.writeFileSync(file, zipStore(files));
}

// export: todo el paquete de entrega en una sola orden
function cmdExport(a) {
  if (!a.events) die("uso: export --events <events.json> [--people people.json] [--existing contacts.csv] [--out-dir dir] [--lang en|es] [--caps JSON] [--registered-days 14,7] [--today ...]");
  const dir = a["out-dir"] && a["out-dir"] !== true ? a["out-dir"] : ".";
  fs.mkdirSync(dir, { recursive: true });
  const b = { ...a, "out-dir": dir, lang: a.lang === "es" ? "es" : "en" };
  cmdCrm(b);
  cmdReport({ ...b, format: "md", out: `${dir}/report.md` });
  cmdReport({ ...b, format: "csv", out: `${dir}/report.csv` });
  cmdIcs({ ...b, out: `${dir}/reminders.ics` });
  cmdDigest({ ...b, out: `${dir}/digest.md` });
}

function findEvent(db, id) {
  const e = eventsOf(db).find((x) => x.id === id);
  if (!e) die(`no existe el evento "${id}"`);
  return e;
}
const optNum = (a, k, lo, hi) => {
  if (a[k] === undefined) return undefined;
  const n = Number(a[k]);
  if (!Number.isFinite(n) || (lo !== undefined && n < lo) || (hi !== undefined && n > hi)) die(`--${k} inválido`);
  return n;
};

function cmdOutcome(a) {
  if (!a.events || !a.id) die("uso: outcome --events <events.json> --id <event-id> --decision attended|skipped [--rating 1-5] [--leads N] [--meetings N] [--opportunities N] [--cost-actual N --currency CAD] [--would-return yes|no] [--reason txt] [--notes txt]");
  if (!["attended", "skipped"].includes(a.decision)) die("--decision debe ser attended o skipped");
  const db = readJson(a.events); const e = findEvent(db, a.id); const t = today(a);
  const o = { ...(e.outcome || {}) };
  const set = (k, v) => { if (v !== undefined && v !== true) o[k] = v; };
  set("rating", optNum(a, "rating", 1, 5)); set("leads", optNum(a, "leads", 0)); set("meetings", optNum(a, "meetings", 0));
  set("opportunities", optNum(a, "opportunities", 0)); set("cost_actual", optNum(a, "cost-actual", 0));
  set("currency", a.currency); set("reason", a.reason); set("notes", a.notes);
  if (a["would-return"] !== undefined) { if (!["yes", "no"].includes(a["would-return"])) die("--would-return: yes|no"); o.would_return = a["would-return"]; }
  o.decision = a.decision; o.recorded_at = t;
  e.outcome = o; e.status = a.decision;
  const warn = a.decision === "attended" && isDate(e.end_date) && e.end_date > t ? [`el evento termina ${e.end_date}, aún no ha pasado`] : [];
  writeJson(a.events, db);
  console.log(JSON.stringify({ id: e.id, status: e.status, outcome: o, warnings: warn }, null, 2));
}

function cmdPostEvent(a) {
  if (!a.events || !a.id) die("uso: post-event --events <events.json> --id <event-id> [--people people.json] [--lang en|es] [--out file.md]");
  const lang = a.lang === "es" ? "es" : "en";
  const e = findEvent(readJson(a.events), a.id);
  const people = a.people && a.people !== true ? readJson(a.people).filter((p) => p.event_id === e.id) : [];
  const ord = { A: 0, B: 1, C: 2 };
  people.sort((x, y) => (ord[x.priority] ?? 2) - (ord[y.priority] ?? 2) || (y.relevance ?? 0) - (x.relevance ?? 0));
  const D = lang === "es"
    ? { h: "Post-evento", due: "Seguimiento", who: "Contactos a seguir", none: "Sin contactos registrados; añade a quienes conociste.", todo: "Pendientes", t1: "Registrar resultado: `outcome --decision attended --rating … --leads … --meetings …`", t2: "Enviar mensajes de seguimiento (borradores; los envías tú)", t3: "Actualizar la hoja CRM (`crm --existing …`)", t4: "Anotar lecciones: ¿volverías? ¿qué cambiarías?", t5: "Guardar notas/fotos de contactos nuevos que conociste", by: "antes de" }
    : { h: "Post-event", due: "Follow-up", who: "Contacts to follow up", none: "No contacts recorded; add the people you met.", todo: "To do", t1: "Record the outcome: `outcome --decision attended --rating … --leads … --meetings …`", t2: "Send follow-up messages (drafts; you send them)", t3: "Update the CRM sheet (`crm --existing …`)", t4: "Write lessons: would you return? what would you change?", t5: "Save notes/photos of new contacts you met", by: "by" };
  const end = isDate(e.end_date) ? e.end_date : e.start_date;
  const L = [`# ${D.h}: ${e.name}`, `${e.start_date || "?"}${e.end_date && e.end_date !== e.start_date ? " → " + e.end_date : ""} · ${[e.city, e.country].filter(Boolean).join(", ")}`, "", `## ${D.who}`, ""];
  if (!people.length) L.push(D.none);
  else for (const p of people) {
    const d = isDate(end) ? addDays(end, FOLLOWUP_DAYS[p.priority] ?? 10) : "";
    L.push(`- [ ] **${p.priority || "C"}** ${p.name}${p.title ? " — " + p.title : ""}${p.company ? ", " + p.company : ""}${d ? ` · ${D.by} ${d}` : ""}${p.why ? `\n  - ${p.why}` : ""}`);
  }
  L.push("", `## ${D.todo}`, "", `- [ ] ${D.t1}`, `- [ ] ${D.t2}`, `- [ ] ${D.t3}`, `- [ ] ${D.t4}`, `- [ ] ${D.t5}`, "");
  const text = L.join("\n");
  if (a.out && a.out !== true) { fs.writeFileSync(a.out, text, "utf8"); console.log(`Post-evento escrito en ${a.out}`); } else process.stdout.write(text);
}

function pearson(xs, ys) {
  const n = xs.length; if (n < 3) return null;
  const mx = xs.reduce((s, v) => s + v, 0) / n, my = ys.reduce((s, v) => s + v, 0) / n;
  let sxy = 0, sxx = 0, syy = 0;
  for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; }
  return sxx === 0 || syy === 0 ? null : sxy / Math.sqrt(sxx * syy);
}
const series = (name) => String(name || "").replace(/\b(19|20)\d{2}\b/g, "").replace(/\s+/g, " ").trim();

function cmdLearn(a) {
  if (!a.events) die("uso: learn --events <events.json> [--goal customers] [--min-events 3] [--out file.json]");
  const events = eventsOf(readJson(a.events));
  const minN = Number(a["min-events"] && a["min-events"] !== true ? a["min-events"] : 3);
  const att = events.filter((e) => e.status === "attended" && e.outcome);
  const rated = att.filter((e) => Number.isFinite(e.outcome.rating));
  const skipped = events.filter((e) => e.status === "skipped" && e.outcome?.reason);
  // ROI
  const byCur = {};
  for (const e of att) {
    const o = e.outcome; const c = o.currency || "n/a";
    const r = (byCur[c] ??= { events: 0, cost: 0, leads: 0, meetings: 0, opportunities: 0 });
    r.events++; r.cost += o.cost_actual || 0; r.leads += o.leads || 0; r.meetings += o.meetings || 0; r.opportunities += o.opportunities || 0;
  }
  for (const r of Object.values(byCur)) { r.cost_per_lead = r.leads ? Math.round(r.cost / r.leads) : null; r.cost_per_meeting = r.meetings ? Math.round(r.cost / r.meetings) : null; }
  // Pesos sugeridos (solo propuesta)
  const goal = a.goal && a.goal !== true ? a.goal : null;
  const base = weightsFor(goal, null);
  let suggested = null; const corr = {};
  const eligible = rated.filter((e) => e.scores);
  if (eligible.length >= minN) {
    suggested = {};
    for (const k of KEYS) {
      const pts = eligible.filter((e) => typeof e.scores[k] === "number");
      const r = pearson(pts.map((e) => e.scores[k]), pts.map((e) => e.outcome.rating));
      corr[k] = r == null ? null : Math.round(r * 100) / 100;
      const delta = r == null || pts.length < minN ? 0 : Math.round(Math.max(-1, Math.min(1, r)) * 5);
      suggested[k] = Math.max(0, Math.round(base[k] * 100) + delta);
    }
  }
  const liked = rated.filter((e) => e.outcome.rating >= 4).map((e) => series(e.name));
  const disliked = rated.filter((e) => e.outcome.rating <= 2).map((e) => series(e.name));
  const reasons = {};
  for (const e of skipped) { const r = norm(e.outcome.reason); reasons[r] = (reasons[r] || 0) + 1; }
  const out = {
    attended: att.length, rated: rated.length, skipped_with_reason: skipped.length,
    enough_data: eligible.length >= minN, min_events: minN,
    liked_arg: [...new Set(liked)].filter((n) => !disliked.includes(n)).join(","), disliked: [...new Set(disliked)],
    criterion_rating_correlation: corr, suggested_weights: suggested,
    skip_reasons: reasons, roi_by_currency: byCur,
    note: suggested ? "Propuesta: muéstrala al usuario; solo con su OK se guarda en profile.learning y se usa con score --weights/--liked." : `Aún no hay datos suficientes (${eligible.length}/${minN} eventos valorados con scores). No cambies los pesos.`,
  };
  if (a.out && a.out !== true) { writeJson(a.out, out); console.log(`Aprendizaje escrito en ${a.out}`); } else console.log(JSON.stringify(out, null, 2));
}


// ---------- relay: correo del reporte al propio usuario via el servicio de Event Radar ----------
// El servidor guarda la clave de Resend; aqui solo viaja el correo del usuario y su clave personal.
const DEFAULT_RELAY = "";
function relayUrl(a) {
  const u = String(a["relay-url"] && a["relay-url"] !== true ? a["relay-url"] : process.env.EVENT_RADAR_RELAY || DEFAULT_RELAY).replace(/\/$/, "");
  if (!u) die("falta --relay-url (reports.relay_url del perfil)");
  return u;
}
async function relayPost(a, p, payload) {
  const r = await fetch(relayUrl(a) + p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  let json = {}; try { json = await r.json(); } catch { /* sin cuerpo */ }
  return { ok: r.ok, status: r.status, json };
}
async function cmdRelayRegister(a) {
  if (!a.email || a.email === true) die("uso: relay-register --email tu@correo.com [--relay-url URL]");
  const r = await relayPost(a, "/api/register", { email: a.email });
  console.log(JSON.stringify({ status: r.status, ...r.json }, null, 2));
  if (!r.ok) process.exit(1);
}
async function cmdRelaySend(a) {
  for (const k of ["email", "key", "subject", "text-file"]) if (!a[k] || a[k] === true) die("uso: relay-send --email tu@correo.com --key CLAVE --subject \"Asunto\" --text-file cuerpo.md [--attach a.xlsx,b.md] [--relay-url URL]");
  const attachments = (a.attach && a.attach !== true ? String(a.attach).split(",") : []).map((p) => ({ filename: p.split(/[\\/]/).pop(), content: fs.readFileSync(p).toString("base64") }));
  const r = await relayPost(a, "/api/send", { email: a.email, key: a.key, subject: a.subject, text: fs.readFileSync(a["text-file"], "utf8"), attachments });
  console.log(JSON.stringify({ status: r.status, ...r.json }, null, 2));
  if (!r.ok) process.exit(1);
}

// ---------- main ----------
const args = parseArgs(process.argv.slice(2));
const cmd = args._[0];
if (cmd === "merge") cmdMerge(args);
else if (cmd === "score") cmdScore(args);
else if (cmd === "report") cmdReport(args);
else if (cmd === "dossier") cmdDossier(args);
else if (cmd === "contacts") cmdContacts(args);
else if (cmd === "reminders") cmdReminders(args);
else if (cmd === "ics") cmdIcs(args);
else if (cmd === "digest") cmdDigest(args);
else if (cmd === "longlist") cmdLonglist(args);
else if (cmd === "status") cmdStatus(args);
else if (cmd === "crm") cmdCrm(args);
else if (cmd === "export") cmdExport(args);
else if (cmd === "relay-register") cmdRelayRegister(args).catch((e) => die(e.message));
else if (cmd === "relay-send") cmdRelaySend(args).catch((e) => die(e.message));
else if (cmd === "outcome") cmdOutcome(args);
else if (cmd === "post-event") cmdPostEvent(args);
else if (cmd === "learn") cmdLearn(args);
else die("comandos: merge | score | report | dossier | contacts | reminders | ics | digest | longlist | status | crm | export | relay-register | relay-send | outcome | post-event | learn");
